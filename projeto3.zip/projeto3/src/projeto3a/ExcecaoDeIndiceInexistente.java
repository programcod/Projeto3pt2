package projeto3a;

public class ExcecaoDeIndiceInexistente extends Exception {
	
	

}
